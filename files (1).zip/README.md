# Cybex backend: the simple version

This folder is a complete server. It runs the website **and** the accounts, progress sync and messages together, so there is nothing to connect. It needs **no installs** except Node.

## Try it on your computer (5 minutes)

1. Install Node from nodejs.org. Pick the **LTS** version (22 or newer).
2. Open a terminal **inside this folder** (`cybex-backend`).
3. Run: `npm start`
4. Open **http://localhost:3000** in your browser.

Go to the **Community** tab and create an account. That's it. Your data is saved in a file called `cybex.db` in this folder. Stop the server with Ctrl+C.

To run the safety checks: `npm test`. You should see `63 passed, 0 failed`.

## Put it online

The easiest way is to host this whole folder on one service. Because the site and the server share one address, cookies and logins just work.

1. Create an account on a host that runs Node apps and gives you a **persistent disk**: Fly.io, Railway, or a small VPS. (Free plans that erase the disk on restart will delete all accounts, so avoid those.)
2. Upload this folder (or connect it through GitHub). Start command: `npm start`
3. Set these settings on the host (see `.env.example`):
   - `NODE_ENV` = `production`
   - `SITE_ORIGIN` = your address, like `https://yourdomain.com`
   - `DB_PATH` = a path on the persistent disk, like `/data/cybex.db`
   - `TRUST_PROXY` = `1`
4. Open your address and test: sign up, log in, send a message.

## If you edit the website file

The site file lives at `public/index.html`. After **any** edit, run this from the folder that has `harden.py`:
`python3 harden.py public/index.html`
Skip it and the browser will show a blank page.

## What this does for you
Passwords are stored scrambled (scrypt). Logins, sign-ups, messages and searches are rate limited. Every change request needs a security token. Profile pictures must be small JPEGs and have location data removed. Blocked people can't message you, and 3 reports in a week pause a sender for 3 days.

## What it does not do (yet)
- **No email**, so no password reset and no email verification. Someone who forgets their password can't recover the account.
- **No two-step login** (MFA).
- Rate limits live in memory, so they reset if the server restarts. Run only one copy of the server.
- Nobody moderates reports for you. They are stored in the database (`reports` table) and you'd read them yourself.
- Back up `cybex.db` regularly.
